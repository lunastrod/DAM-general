/*
 * Copyright 2010-2021 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package kotlin.js

import JsError
import kotlin.internal.UsedFromCompilerGeneratedCode

@UsedFromCompilerGeneratedCode
internal fun unreachableDeclarationLog() {
    console.asDynamic().trace("Unreachable declaration")
}

@UsedFromCompilerGeneratedCode
internal fun unreachableDeclarationException() {
    throw JsError("Unreachable declaration")
}
