//@autor: Daniel Parra Segovia
//@correcci�n:damaga
//################################################################################
//Crea una aplicaci�n que pida un n�mero y calcule su factorial (El factorial de
//un n�mero es el producto de todos los enteros entre 1 y el propio n�mero y se
//representa por el n�mero seguido de un signo de exclamaci�n.
//Por ejemplo 5! = 1x2x3x4x5=120)
//################################################################################
//An�lisis
// Solicitud de entrada: numero entero mayor que 1
// C�lculo del factorial
//		Entrada: el numero entero 
//		Proceso: acumular la multiplicacion de todos los enteros anteriores en una variable
//		Salida: la variable acumuladora
// Presentaci�n de resultado: resultado del factorial
//################################################################################
//Dise�o
// Variables:
//		n: Entero, lectura por teclado
//		factorial: variable acumuladora, inicializada en 1
//		i: variable que valdr� cada numero entero mayor que 1 menor o igual que n en el bucle
// C�lculo:
//		Un bucle for i desde 2 hasta n que acumule factorial*=i;
//################################################################################ 

Algoritmo sin_titulo
	Definir n,factorial,i Como Entero;
	Escribir "Introduce n";
	Leer n;
	factorial:=1;
	Para i<-2 Hasta n Con Paso 1 Hacer
		factorial:=factorial*i;
	FinPara
	Escribir n,"! = ",factorial;
FinAlgoritmo
//Perfecto, muy lindo UwU