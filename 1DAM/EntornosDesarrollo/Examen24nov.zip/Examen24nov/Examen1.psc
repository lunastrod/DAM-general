// // ################################################################################
// An�lisis
// Necesito generar un n�mero aleatorio, lo guardo en variable entera
// Necesito un contador de 0 a 10, voy a crear 2 variables enteras,
//		el contador y una que act�e como constante para guardar el m�ximo de intentos
// Necesito una variable entera para guardar el n�mero del usuario
// Mientras que mi contador sea <10 o el n�mero a�n no se haya adivinado, pido n�meros al usuario
// Necesito una variable true/false para guardar si el usuario ha adivinado el n�mero y poder cortar el bucle
// Cuando haya le�do el n�mero del usuario tengo que comprobar si es mayor, menor o igual al numero aleatorio
// ################################################################################
// Dise�o
// Mis variables son:
// 		contador de intentos: intentos
//		constante numero de intentos:intentosMax
//		guardar numero aleatorio:nAleatorio
//		guardar input de usuario: intentoUsuario
// 		boolean para terminar: adivinado
// Asigno valores a las que haga falta
// Bucle mientras con condici�n NO adivinado Y intentos<intentosMax
// 		incremento contador de intentos
// 		leo valor de usuario
//		compruebo si es mayor, menor o igual (Dos if anidados)
//	Escribo en funci�n de si ha adivinado o no
// ################################################################################

Proceso Examen1
	Definir intentos,intentosMax,nAleatorio,intentoUsuario Como Entero;
	Definir adivinado Como Logico;
	
	intentos<-0;
	intentosMax<-10;
	nAleatorio<-Aleatorio(0,100);
	adivinado<-Falso;
	
	Escribir "Intenta adivinar un n�mero aleatorio entre 0 y 100";
	Mientras NO adivinado Y intentos<intentosMax Hacer
		intentos<-intentos+1;
		Escribir "Intento ",intentos;
		Escribir "Escribe un numero";
		Leer intentoUsuario;
		Si intentoUsuario=nAleatorio Entonces
			adivinado<-Verdadero;
		SiNo
			Si nAleatorio>intentoUsuario Entonces
				Escribir "El n�mero aleatorio es mayor";
			SiNo
				Escribir "El n�mero aleatorio es menor";
			FinSi
		FinSi
	FinMientras
	
	Si adivinado Entonces
		Escribir "�Has adivinado el n�mero!";
	SiNo
		Escribir "Has superado ",intentosMax," intentos, el n�mero era ", nAleatorio;
	FinSi
	
FinProceso